globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/99rsllgNTtT-OJ-EaS7LD/_buildManifest.js",
    "static/99rsllgNTtT-OJ-EaS7LD/_ssgManifest.js",
    "static/99rsllgNTtT-OJ-EaS7LD/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0f5gg_0xvp-xu.js",
    "static/chunks/0ksj0ky_s6b0l.js",
    "static/chunks/17f3_ywqb3feh.js",
    "static/chunks/0.-~81nlmzqna.js",
    "static/chunks/turbopack-0ydtl66uqlgc8.js"
  ]
};
