module.exports=[42035,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_fiksi__next-internal_server_app_page_actions_02dddfo.js.map