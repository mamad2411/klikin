module.exports=[71914,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_fiksi__next-internal_server_app__not-found_page_actions_0790nl1.js.map