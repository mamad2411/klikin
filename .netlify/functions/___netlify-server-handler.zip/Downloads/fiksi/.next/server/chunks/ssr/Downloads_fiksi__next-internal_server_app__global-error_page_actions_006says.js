module.exports=[7521,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_fiksi__next-internal_server_app__global-error_page_actions_006says.js.map