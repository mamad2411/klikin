module.exports=[5902,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}}];

//# sourceMappingURL=0py1_%40swc_helpers_cjs__interop_require_default_cjs_0nivx45._.js.map